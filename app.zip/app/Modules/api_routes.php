<?php

include_once  base_path("app/Modules/User/Route.php");
include_once  base_path("app/Modules/Category/Route.php");
include_once  base_path("app/Modules/BlogManagement/Blog/Route.php");
include_once  base_path("app/Modules/CourseManagement/Course/Route.php");
include_once  base_path("app/Modules/Slider/Route.php");
include_once  base_path("app/Modules/WebsiteSetting/Route.php");
