<div class="section-title my-5">
    <div class="btn btn-lg" href="#">
        <span>{{$title}} </span>
    </div>
</div>
