<template>
    <div>
        all reports
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
