let setup = {
    page_title: `WebsiteSetting Management`,
    route_prefix: `WebsiteSetting`,
}
export default setup;