let setup = {
    page_title: `Category Management`,
    route_prefix: `Category`,
}
export default setup;