let setup = {
    page_title: `Blog Management`,
    route_prefix: `Blog`,
}
export default setup;