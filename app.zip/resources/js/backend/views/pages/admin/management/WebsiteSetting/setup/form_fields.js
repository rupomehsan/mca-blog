export default [
    {
        name: "field_title",
        label: "Enter your  title",
        type: "text",
        value: "",
    },
    {
        name: "field_value",
        label: "Enter your  value",
        type: "textarea",
        value: "",
    },
];
