export default [
    {
        name: "title",
        label: "Enter your  title",
        type: "text",
        value: "",
    },
    {
        name: "description",
        label: "Enter your  description",
        type: "text",
        value: "",
    },
    {
        name: "image",
        label: "Upload your image",
        type: "file",
        value: null,
        multiple: false,
    },
];
