let setup = {
    page_title: `Slider Management`,
    route_prefix: `Slider`,
}
export default setup;