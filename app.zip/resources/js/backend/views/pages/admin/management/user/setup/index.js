let setup = {
    page_title: `User Management`,
    route_prefix: `User`,
}

export default setup;
