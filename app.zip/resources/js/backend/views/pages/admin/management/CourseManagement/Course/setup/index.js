let setup = {
    page_title: `Course Management`,
    route_prefix: `Course`,
}
export default setup;