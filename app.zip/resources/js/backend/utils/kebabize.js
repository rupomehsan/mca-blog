export default function(str){
    return str;
}
