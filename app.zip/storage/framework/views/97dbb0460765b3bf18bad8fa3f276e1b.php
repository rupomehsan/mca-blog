<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>MCA Admin Panel</title>
    <!-- loader-->
    <link href="<?php echo e(asset('backend/assets/css/pace.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('backend/assets/js/pace.min.js')); ?>"></script>
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>" type="image/x-icon">
    <!-- Vector CSS -->
    <link href="<?php echo e(asset('backend/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet" />
    <!-- simplebar CSS-->
    <link href="<?php echo e(asset('backend/assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- animate CSS-->
    <link href="<?php echo e(asset('backend/assets/css/animate.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons CSS-->
    <link href="<?php echo e(asset('backend/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Metismenu CSS-->
    <link href="<?php echo e(asset('backend/assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('backend/assets/css/app-style.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugins/summernote/dist/summernote-bs4.css')); ?>" />
    <!-- latest jquery-->
    <script src="/backend/assets/js/sweet_alert.js" defer></script>
    <script src="/backend/assets/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/inputtags/js/bootstrap-tagsinput.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/backend/app.js']); ?>
</head>

<body class="bg-theme bg-theme1" id="body">
    <div id="app">
        <app></app>
    </div>
</body>

</html>
<?php /**PATH D:\LARAVEL VUE\mca-modern-cooking-academy-main\mca-modern-cooking-academy-main\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>