<div class="section-title my-5">
    <div class="btn btn-lg" href="#">
        <span><?php echo e($title); ?> </span>
    </div>
</div>
<?php /**PATH D:\LARAVEL VUE\mca-modern-cooking-academy-main\mca-modern-cooking-academy-main\resources\views/components/section-title.blade.php ENDPATH**/ ?>