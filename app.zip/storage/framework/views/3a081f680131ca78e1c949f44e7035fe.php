<?php $__env->startSection('content'); ?>
<!-- Page Title -->
<section class="page-title" style="background-image:url(<?php echo e(asset('frontend/images/background/17.png')); ?>)">
    <div class="auto-container">
        <h1>404</h1>
    </div>
</section>
<!--End Page Title-->

<!--Error Section-->
<section class="error-section">
    <div class="auto-container">
        <div class="content">
            <h1>404</h1>
            <h2>Oops! That page can’t be found</h2>
            <div class="text">Sorry, but the page you are looking for does not existing</div>
            <a href="index.html" class="theme-btn btn-style-one"><span class="txt">Go to home page</span></a>
        </div>
    </div>
</section>
<!--End Error Section-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Ehsan\mca\app\resources\views/frontend/not-found.blade.php ENDPATH**/ ?>